#include <reproc/reproc.h>

const unsigned int REPROC_INFINITE = 0xFFFFFFFF;
