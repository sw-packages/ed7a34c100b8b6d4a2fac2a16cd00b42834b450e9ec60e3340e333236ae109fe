#ifndef REPROC_POSIX_FD_H
#define REPROC_POSIX_FD_H

void fd_close(int *fd);

#endif
