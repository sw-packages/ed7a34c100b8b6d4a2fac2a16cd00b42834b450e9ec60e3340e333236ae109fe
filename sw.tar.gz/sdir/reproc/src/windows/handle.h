#ifndef REPROC_WINDOWS_HANDLE_H
#define REPROC_WINDOWS_HANDLE_H

#include <windows.h>

void handle_close(HANDLE *handle);

#endif
